//
//  DayHealthData.swift
//  Homework 1
//
//  Created by Omar Perez on 9/26/17.
//  Copyright © 2017 Omar Perez. All rights reserved.
//

import Foundation

class HealthData {
    
    var runningTime:Int = 0
    var runningCalories:Int = 0
    var strExTime:Int = 0
    var strExCalories:Int = 0
    var foodIntakeCalories:Int = 0
    var weight:Int = 0
    var bloodPressure:Int = 0
    
}
